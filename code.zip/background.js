let timeSpent = {};
let activeTab = null;
let startTime = null;

// Function to update time spent on the active tab
function updateTime() {
    if (activeTab && startTime) {
        const endTime = Date.now();
        const timeElapsed = (endTime - startTime) / 1000; // Convert to seconds
        timeSpent[activeTab] = (timeSpent[activeTab] || 0) + timeElapsed;
        chrome.storage.local.set({ timeSpent });
        startTime = Date.now(); // Reset start time
    }
}

// Function to track the currently active tab
function trackActiveTab(tabId) {
    chrome.tabs.get(tabId, (tab) => {
        if (tab && tab.url) {
            updateTime(); // Update previous tab time
            activeTab = new URL(tab.url).hostname.replace(/^www\./, '');
            startTime = Date.now();
        }
    });
}

// When tab is activated
chrome.tabs.onActivated.addListener((activeInfo) => {
    trackActiveTab(activeInfo.tabId);
});

// When a tab is updated (reload, new page)
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (tab.active && changeInfo.url) {
        trackActiveTab(tabId);
    }
});

// Handle window focus changes
chrome.windows.onFocusChanged.addListener((windowId) => {
    if (windowId === chrome.windows.WINDOW_ID_NONE) {
        updateTime(); // Save time before losing focus
        activeTab = null;
        startTime = null;
    } else {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs.length > 0) trackActiveTab(tabs[0].id);
        });
    }
});

// Send updated time data to popup.js on request
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "getTimeData") {
        updateTime(); // Ensure the latest time is saved
        sendResponse({ timeSpent });
    }
    return true; // Required for async response
});

// Update every second
setInterval(updateTime, 1000);
