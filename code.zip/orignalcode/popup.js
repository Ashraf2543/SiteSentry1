document.addEventListener('DOMContentLoaded', () => {
    const timeList = document.getElementById('timeList');
    const clearDataBtn = document.createElement('button');
    clearDataBtn.textContent = "Clear Data";
    clearDataBtn.className = "clear-btn";
    document.body.appendChild(clearDataBtn);

    function getDomainName(url) {
        try {
            return new URL(`https://${url}`).hostname.replace(/^www\./, '').split('.')[0];
        } catch {
            return url;
        }
    }

    function getFavicon(url) {
        return `https://www.google.com/s2/favicons?sz=32&domain=${url}`;
    }

    function formatTime(seconds) {
        let h = Math.floor(seconds / 3600);
        let m = Math.floor((seconds % 3600) / 60);
        let s = Math.floor(seconds % 60);
        return `${h ? h + 'h ' : ''}${m ? m + 'm ' : ''}${s}s`;
    }

    function updatePopup() {
        chrome.runtime.sendMessage({ action: 'getTimeData' }, (response) => {
            if (!response) return;

            timeList.innerHTML = '';
            const timeData = response.timeSpent || {};
            
            // Get the currently active tab
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                let activeTab = tabs.length > 0 ? new URL(tabs[0].url).hostname.replace(/^www\./, '') : null;
                
                // Convert time data to array and sort by time spent in descending order
                let sortedEntries = Object.entries(timeData).sort((a, b) => b[1] - a[1]);
                
                if (activeTab) {
                    // Move active tab to the top
                    sortedEntries = sortedEntries.filter(([site]) => site !== activeTab);
                    sortedEntries.unshift([activeTab, timeData[activeTab] || 0]);
                }

                sortedEntries.forEach(([site, time]) => {
                    const div = document.createElement('div');
                    div.className = 'site';

                    const icon = document.createElement('img');
                    icon.src = getFavicon(site);
                    icon.className = 'site-icon';
                    icon.onerror = () => (icon.style.display = 'none');

                    const name = document.createElement('span');
                    name.className = 'site-name';
                    name.textContent = getDomainName(site);

                    const timeText = document.createElement('span');
                    timeText.className = 'site-time';
                    timeText.textContent = formatTime(time);

                    div.appendChild(icon);
                    div.appendChild(name);
                    div.appendChild(timeText);
                    timeList.appendChild(div);
                });
            });
        });
    }

    // Clear Data Button
    clearDataBtn.addEventListener('click', () => {
        chrome.runtime.sendMessage({ action: 'clearData' }, () => {
            updatePopup(); // Refresh UI after clearing
        });
    });

    updatePopup(); // Initial update
    setInterval(updatePopup, 1000); // Keep updating every second
});
